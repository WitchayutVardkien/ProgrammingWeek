def show_info():
    print("finds the average of 3 numbers")


def average(a, b, c):
    return (a + b + c) / 3


# main
show_info()
n1 = float(input("number 1: "))
n2 = float(input("number 2: "))
n3 = float(input("number 3: "))

avg = average(n1, n2, n3)
print("Average =", avg)

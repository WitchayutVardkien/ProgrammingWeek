def setup():
    size(500, 400)
    background(255)

def draw():
    line(190, 120, 310, 120) 
    line(310, 120, 380, 280)   
    line(380, 280, 120, 280)   
    line(120, 280, 190, 120)   

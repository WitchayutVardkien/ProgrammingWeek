def show_info():
    print("calculates BMI")
    print("BMI = weight / (height * height)")


def cal_bmi(weight, height):
    return weight / (height * height)


show_info()
weight = float(input("weight (kg): "))
height = float(input("height (meter): "))

bmi = cal_bmi(weight, height)
print("Your BMI =", bmi)

if bmi < 18.5:
    print("ผอม")
elif bmi >= 18.5 and bmi < 25:
    print("ปกติ")
elif bmi >= 25:
    print("น้ำหนักเกิน")
